%ICD Sensing Function
%input: TBD
% % parameter struct
% (initial settings)
%ICD_sense_state
%State: 1 - sensing/AGC
%       2 - peak tracking
%       3 - absolute blanking
%       4 - noise window
%       5 - fixed refractory
% ICD_sense_state.State=1;
% ICD_sense_state.VPace=0;
% ICD_sense_state.VSense=0;
% ICD_sense_state.APace=0;
% ICD_sense_state.ASense=0;
% ICD_sense_state.StateClock=0;
% ICD_sense_state.StateClockLim=0;
% ICD_sense_state.RefPeriodClock=0;
% ICD_sense_state.VThres=vThresMin;
% ICD_sense_state.VType=1;
% ICD_sense_state.VAvg=vThresMin;%TODO: could be different initial value
% ICD_sense_state.DebugClock=0;

% current state
% current waveform sample (vector)
%output: TBD
% input waveform
% current threshold
%TODO: what happens when there is a VPACE event, but it is not sensed?
function [signal, V_in, A_in, A_blank,ICD_sense_state, ICD_sense_param]=ICD_sensing_MED_A(...
    ICD_sense_state, ICD_sense_param,...
    signal)

V_in=0;
A_in=0;
A_blank=0;
signal=abs(signal);
ICD_sense_state.DebugClock=ICD_sense_state.DebugClock+1;
ICD_sense_param.DebugClock=ICD_sense_param.DebugClock+1;
%Sensing
if(ICD_sense_state.AState==1)
    
    if(signal(1,:)>=ICD_sense_state.AThres)
        ICD_sense_state.AState=2;
        ICD_sense_state.AStateClock=0;
        ICD_sense_state.AStateClockLim=ICD_sense_param.ABlankAfterSense;
        ICD_sense_state.AAGCOn=0;
        if(ICD_sense_state.APace==0)
            ICD_sense_state.ASense=1;
            A_in=1;
            
        end
        if(ICD_sense_state.APace==0)
            
            ICD_sense_state.AType=1;
        else
            ICD_sense_state.AType=2;
        end
        
    else
        ICD_sense_state.AStateClock=ICD_sense_state.AStateClock+1;
        
        
    end
    
    
    %PeakTracking
elseif(ICD_sense_state.AState==2)
    ICD_sense_state.AStateClock=ICD_sense_state.AStateClock+1;
    if(ICD_sense_state.ASense==1)
        ICD_sense_state.ASense=0;
    end
    if(signal<ICD_sense_state.AThres)
        ICD_sense_state.AStateClock=0;
        ICD_sense_state.AStateClockLim=ICD_sense_param.ABlankAfterSense;
        ICD_sense_state.AState=3;
        
        %update start threshold
        if(ICD_sense_state.AType==1)
            
            
            ICD_sense_state.AThres=ICD_sense_state.AThres*0.75;
            ICD_sense_state.AThres0=ICD_sense_state.AThres;
            ICD_sense_state.AThresMax=8*ICD_sense_param.AThresMin;
            ICD_sense_state.AThresMin=ICD_sense_param.AThresMin;
            ICD_sense_state.AExpFactor=(-1/3)*log(ICD_sense_state.AThresMin/(ICD_sense_state.AThres));
            ICD_sense_state.AAGCClock=0;
        elseif(ICD_sense_state.AType==2)
            %TODO: state change after pace
        end
    else
        %while peak is going up
        ICD_sense_state.AThres=signal;
    end
    
    %Blanking After Sense
elseif(ICD_sense_state.AState==3)
    ICD_sense_state.AAGCOn=1;
    if(ICD_sense_state.AStateClock>=ICD_sense_state.AStateClockLim)
        ICD_sense_state.AStateClock=0;
        ICD_sense_state.AState=1;
    else
        ICD_sense_state.AStateClock=ICD_sense_state.AStateClock+1;
    end
    
    %Blanking After Pace
elseif(ICD_sense_state.AState==4)
    %TODO
    
    %Cross Chamber Blank
elseif(ICD_sense_state.AState==5)
    %TODO
    
end
%AGC
if(ICD_sense_state.AAGCOn==1)
    ICD_sense_state.AAGCClock=ICD_sense_state.AAGCClock+1;
    %TODO:Do I need to keep track of AGC clock?, maybe?
    t=ICD_sense_state.AAGCClock;
    if(ICD_sense_state.AThres>=ICD_sense_param.AThresMin)
        ICD_sense_state.AThres=ICD_sense_state.AThres0*...
            exp((-1*ICD_sense_state.AExpFactor*t)/ICD_sense_param.ATC);
        
    end
    
end
end