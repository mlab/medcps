%medtronic wavelet morphology comparison
%assumes 'Haar' Wavelet & no downsampling
%assumes that the template will be a length of a power of 2
%if waveform is of different length, the template will concatenate it to
%match length of template if longer, and pad with zeros 
%displays warning in either case
%
%input: - one event waveform
%       - template to compare
%       - DS: Downsample ratio (integer)
%       - debug: 1 - print debug output 0 - supress debug output
%output: 
%        - match_percentage: percent of matching coeffs. (value from 0 to 1)
function [match_percentage fh]= med_wave_morph_comp(waveform,template, DS, debug)
fh=0;
%sanity check - concatenate waveform to length of template
if(length(template)<length(waveform))
    if debug
        display('wave_morph_comp: length do not match - waveform longer than template')
    end
    waveform=waveform(1:length(template));
elseif(length(template) >length(waveform))
    if debug
        display('wave_morph_comp: length do not match - waveform shorter than template')
    end
    temp=zeros(size(template));
    temp(1:length(waveform),:)=waveform;
    waveform=temp;    
end
%downsample
template=template(1:DS:length(template));
waveform=waveform(1:DS:length(waveform));
%compute max wavelet level
wname='haar';
%levels=floor(abs(wmaxlev(template,wname)));
%compute decomposition for template
levels=floor(log2(length(template)))-2;
[CTempl LTempl]=wavedec(template,levels,wname);
%compute decomposition for waveform
[CWave LWave]=wavedec(waveform,levels,wname);

%normalize
maxCoeff=max(CTempl);
recThres=maxCoeff/32;
%CTempl(CTempl<recThres)=0;
CTempl=CTempl/maxCoeff;

maxCoeff=max(CWave);
recThres=maxCoeff/32;
%CWave(CWave<recThres)=0;
CWave=CWave/maxCoeff;


%calculate match percentage
%nonZeroInd=find(CTempl~=0);
%CTempl=CTempl(nonZeroInd);
%CWave=CWave(nonZeroInd);
%temp=sum(abs(CTempl-CWave)./abs(CTempl))'
selectInd=LTempl(1)*2:length(CTempl);
temp=sum(abs(CTempl(selectInd)-CWave(selectInd)))/sum(abs(CTempl(selectInd)));
match_percentage=1-(temp);
if(debug)
    fh=figure;
    subplot(2,1,1)
    plot(template);
    hold on
    plot(waveform);
    subplot(2,1,2)
    CWave(1:LTempl(1)*2)=0;
    CTempl(1:LTempl(1)*2)=0;
    WaveReconst=waverec(CWave,LWave,wname);
    TemplReconst=waverec(CTempl,LTempl,wname);
    plot(TemplReconst);
    hold on
    plot(WaveReconst);
end

end