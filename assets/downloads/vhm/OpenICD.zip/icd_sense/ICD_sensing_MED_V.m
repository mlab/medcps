%ICD Sensing Function
%input: TBD
% % parameter struct
% (initial settings)
%ICD_sense_state
%State: 1 - sensing/AGC
%       2 - peak tracking
%       3 - absolute blanking
%       4 - noise window
%       5 - fixed refractory
% ICD_sense_state.State=1;
% ICD_sense_state.VPace=0;
% ICD_sense_state.VSense=0;
% ICD_sense_state.APace=0;
% ICD_sense_state.ASense=0;
% ICD_sense_state.StateClock=0;
% ICD_sense_state.StateClockLim=0;
% ICD_sense_state.RefPeriodClock=0;
% ICD_sense_state.VThres=vThresMin;
% ICD_sense_state.VType=1;
% ICD_sense_state.VAvg=vThresMin;%TODO: could be different initial value
% ICD_sense_state.DebugClock=0;

% current state
% current waveform sample (vector)
%output: TBD
% input waveform
% current threshold
%TODO: what happens when there is a VPACE event, but it is not sensed?
function [signal, V_in, A_in,V_blank, ICD_sense_state, ICD_sense_param]=ICD_sensing_MED_V(...
    ICD_sense_state, ICD_sense_param,...
    signal)

V_in=0;
A_in=0;
V_blank=0;
signal=abs(signal);
ICD_sense_state.DebugClock=ICD_sense_state.DebugClock+1;
ICD_sense_param.DebugClock=ICD_sense_param.DebugClock+1;
%Sensing
if(ICD_sense_state.VState==1)
    
    if(signal(1,:)>=ICD_sense_state.VThres)
        ICD_sense_state.VState=2;
        ICD_sense_state.VStateClock=0;
        ICD_sense_state.VStateClockLim=ICD_sense_param.VBlankAfterSense;
        ICD_sense_state.VAGCOn=0;
        if(ICD_sense_state.VPace==0)
            ICD_sense_state.VSense=1;
            V_in=1;
            
        end
        if(ICD_sense_state.VPace==0)
            
            ICD_sense_state.VType=1;
        else
            ICD_sense_state.VType=2;
        end
        
    else
        ICD_sense_state.VStateClock=ICD_sense_state.VStateClock+1;
        
        
    end
    
    
    %PeakTracking
elseif(ICD_sense_state.VState==2)
    ICD_sense_state.VStateClock=ICD_sense_state.VStateClock+1;
    if(ICD_sense_state.VSense==1)
        ICD_sense_state.VSense=0;
    end
    if(signal<ICD_sense_state.VThres)
        ICD_sense_state.VStateClock=0;
        ICD_sense_state.VStateClockLim=ICD_sense_param.VBlankAfterSense;
        ICD_sense_state.VState=3;
        
        %update start threshold
        if(ICD_sense_state.VType==1)
            
            
            ICD_sense_state.VThres=ICD_sense_state.VThres*0.75;
            ICD_sense_state.VThres0=ICD_sense_state.VThres;
            ICD_sense_state.VThresMax=8*ICD_sense_param.VThresMin;
            ICD_sense_state.VThresMin=ICD_sense_param.VThresMin;
            ICD_sense_state.VExpFactor=(-1/3)*log(ICD_sense_state.VThresMin/(ICD_sense_state.VThres));
            ICD_sense_state.VAGCClock=0;
        elseif(ICD_sense_state.VType==2)
            %TODO: state change after pace
        end
    else
        %while peak is going up
        ICD_sense_state.VThres=signal;
    end
    
    %Blanking After Sense
elseif(ICD_sense_state.VState==3)
    ICD_sense_state.VAGCOn=1;
    V_blank=1;
    if(ICD_sense_state.VStateClock>=ICD_sense_state.VStateClockLim)
        ICD_sense_state.VStateClock=0;
        ICD_sense_state.VState=1;
    else
        ICD_sense_state.VStateClock=ICD_sense_state.VStateClock+1;
    end
    
    %Blanking After Pace
elseif(ICD_sense_state.VState==4)
    %TODO
    
    %Cross Chamber Blank
elseif(ICD_sense_state.VState==5)
    %TODO
    
end
%AGC
if(ICD_sense_state.VAGCOn==1)
    ICD_sense_state.VAGCClock=ICD_sense_state.VAGCClock+1;
    %TODO:Do I need to keep track of AGC clock?, maybe?
    t=ICD_sense_state.VAGCClock;
    if(ICD_sense_state.VThres>ICD_sense_param.VThresMin)
        ICD_sense_state.VThres=ICD_sense_state.VThres0*...
            exp((-1*ICD_sense_state.VExpFactor*t)/ICD_sense_param.VTC);
    elseif(ICD_sense_state.VThres<=ICD_sense_param.VThresMin)
            ICD_sense_state.VThres=ICD_sense_state.VThresMin;
        
    end
    
end
end