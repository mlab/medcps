%ICD_sensing_BS_init
%Initializes data structure which is use throughout sensing algorithm
%ICD_sense_state
%State: 1 - sensing/AGC
%       2 - peak tracking
%       3 - absolute blanking
%       4 - noise window
%       5 - fixed refractory
%
%(Flags which should be reset when output is set. Intended use is for
%signalling different processes during the function)
%VPace: 1 - occurred; 0 - not occurred
%VSense: 1- occurred; 0 - not occurred 
%APace: 1- occurred; 0 - not occurred
%ASense: 1- Sense Event; 0 - No Event (should be impulse) 
%VThres: Detection threshold (uV)
%StateClock: Clock for time in each state;
%RefPeriodClock: Refractory Period Clock (total time since beginning of
%event)
%FixedRefPeriodClock
%VType: Type of last event (0 - no event 1 - Vsense 2 - VPace)
%debugClock: clock used for debugging
%
%ICD_sense_param
%VThresMin: current threshold minimum for ventricular sense (should start at minimum)

function [ICD_sense_state, ICD_sense_param]= ICD_sensing_init_MED (...
    vThresNom,  vThresMin, vTC,...
    vBlankAfterSense, vBlankAfterPace,vCrossChamberBlank, ...
    aThresNom,  aThresMin, aTC,...
    aBlankAfterSense, aBlankAfterPace,aCrossChamberBlank)

ICD_sense_state.VState=1;
ICD_sense_state.VPace=0;
ICD_sense_state.VSense=0;
ICD_sense_state.APace=0;
ICD_sense_state.ASense=0;
ICD_sense_state.VStateClock=0;
ICD_sense_state.VStateClockLim=0;
ICD_sense_state.VRefPeriodClock=0;
ICD_sense_state.VThres=vThresNom;
ICD_sense_state.VType=1;
ICD_sense_state.VAvg=vThresNom;%TODO: could be different initial value
ICD_sense_state.DebugClock=0;
ICD_sense_state.VThresMax=vThresMin*8;%TODO: Changes for Medtronic
ICD_sense_state.VThres0=vThresNom;
%Difference from Boston Scientific --> Minimum is programmed
ICD_sense_state.VThresMin=vThresMin;
ICD_sense_state.VExpFactor=(-1/3)*log(ICD_sense_state.VThresMin/(ICD_sense_state.VThres));
ICD_sense_state.VAGCOn=1;
ICD_sense_state.VAGCClock=0;
%TODO: Buffer
ICD_sense_state.VBuffer=[0;0;0];
ICD_sense_state.VBufInd=1;

ICD_sense_param.VThresNom=vThresNom;
ICD_sense_param.VThresMin=vThresMin;
ICD_sense_param.VBlankAfterSense=vBlankAfterSense;
ICD_sense_param.VBlankAfterPace=vBlankAfterPace;
ICD_sense_param.VCrossChamberBlank=vCrossChamberBlank;
ICD_sense_param.VTC=vTC;
ICD_sense_param.DebugClock=0;
%%%%%%%%%
ICD_sense_state.AState=1;
ICD_sense_state.AStateClock=0;
ICD_sense_state.AStateClockLim=0;
ICD_sense_state.ARefPeriodClock=0;
ICD_sense_state.AThres=aThresNom;
ICD_sense_state.AType=1;
ICD_sense_state.AAvg=aThresNom;%TODO: could be different initial value
ICD_sense_state.DebugClock=0;
ICD_sense_state.AThresMax=aThresMin*8;%TODO: Changes for Medtronic
ICD_sense_state.AThres0=aThresNom;
%Difference from Boston Scientific --> Minimum is programmed
ICD_sense_state.AThresMin=aThresMin;
ICD_sense_state.AExpFactor=(-1/3)*log(ICD_sense_state.AThresMin/(ICD_sense_state.AThres));
ICD_sense_state.AAGCOn=1;
ICD_sense_state.AAGCClock=0;
%TODO: Buffer
ICD_sense_state.ABuffer=[0;0;0];
ICD_sense_state.ABufInd=1;

ICD_sense_param.AThresNom=aThresNom;
ICD_sense_param.AThresMin=aThresMin;
ICD_sense_param.ABlankAfterSense=aBlankAfterSense;
ICD_sense_param.ABlankAfterPace=aBlankAfterPace;
ICD_sense_param.ACrossChamberBlank=aCrossChamberBlank;
ICD_sense_param.ATC=aTC;
end