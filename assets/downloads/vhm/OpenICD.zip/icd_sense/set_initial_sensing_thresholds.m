function [ath,vth] = set_initial_sensing_thresholds(EGM, method, varargin)

global debugprog;
debugme = debugprog;
plotit=0;

Mv = max(abs(EGM.VSigRaw));
Ma = max(abs(EGM.ASigRaw));
M = max(Ma,Mv);
if nargin < 3
    decrement = 0.3*Mv;
end
maxnbeats = length(EGM.VSigRaw);

[truenbAbeats, truenbVbeats] = count_true_beats(EGM);
Atolerance = floor(0.1*truenbAbeats);
Vtolerance = floor(0.1*truenbVbeats);
if debugme
    fprintf('%d True A beats, %d True V beats, tolerances (%d, %d)\n',truenbAbeats, truenbVbeats, Atolerance,  Vtolerance)
end

already_set_vth = 0;
already_set_ath = 0;
% Since we don't care about WS here, we set it to the usual 0.5
k=[1,1,0.5];
ath = nan;
vth = nan;
while ~(already_set_vth && already_set_ath)
    % Get the beats
    [WA,WV,~, ~] = get_single_beats(EGM,method,maxnbeats,[-k(1)*decrement, -k(2)*decrement, k(3)]);
    if debugme 
        fprintf('%d A beats, %d V beats, Th= %d, %d\n', ...
            size(WA,1), size(WV,1),...
            Ma-k(1)*decrement, Mv-k(2)*decrement);
    end

    % If the nb of beats is within tolerance of the true value, stop
    % decrementing
    if abs(size(WA,1) - truenbAbeats) <= Atolerance || Ma-(k(1)+1)*decrement <= 0
        ath = M - k(1)*decrement;
        already_set_ath = 1;
    else
        k(1) = k(1)+1;
    end
    if abs(size(WV,1) - truenbVbeats) <= Vtolerance || Mv-(k(2)+1)*decrement <= 0
        vth = M - k(2)*decrement;
        already_set_vth = 1;
    else
        k(2) = k(2)+1;
    end
    
    if Ma-k(1)*decrement <0 || Mv-k(2)*decrement < 0
        warning('Negative sensing threshold')
        keyboard
    end
    
end