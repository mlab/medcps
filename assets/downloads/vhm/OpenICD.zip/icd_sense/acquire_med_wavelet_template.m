%Function for acquiring NSR template for Medtronic wavelet morphology
%algorithm
%This function expects to receive at least 30000ms (30 Secs) of an NSR EGM,
%or an egm containing at least 6 NSR beats
%If an egm will less best is input, the function will output a template based on
%the beats existing in the EGM
%
%input:
%   - events: structure containing Vin sensed for NSR EGM to acquire
%   template from
%   - Med_state: ICD_state structure for medtronic
%   - egm: EGM to train NSR from
%   - window_length: length of template to train (typically 128
%   - DS: downsampling ratio (typically 4)
%   - nb_averaged_beats: parameters for specifying number of beats to use
%   in template (nomimally 6 beats)
%   -debug: print debug output and draw figures for function
%output:
%   - Med_state struct containing NSR Template


function Med_state= acquire_med_wavelet_template(NSR_length,events,Med_state,egm, window_length,DS, nb_averaged_beats, debug)
%script for acquiring template from NSR records for patient
global debugprog;
debugme = debugprog;

%setup variables
wave_win_array=zeros(window_length,nb_averaged_beats);
globalMatchRatio=-inf;
curVin=events.Vin(1:NSR_length);
curShockSig=egm.currentRec(:,7);
eventInd=find(curVin);
winLen=window_length;
halfWin=floor(winLen/2);
cur_nb_averaged_beats=nb_averaged_beats;
if size(eventInd) < nb_averaged_beats
    warning(sprintf('Did not find %d beats for Wavelet',nb_averaged_beats))
    [~, ~, WS] = get_single_beats(egm,'fixed window',nb_averaged_beats, 0.75, 'raw');
    eventInd=WS(:,1)+50;
    cur_nb_averaged_beats=size(eventInd,1);
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Begin training
beginInd=1;
%check ranges
startInd=max([1 eventInd(beginInd)-(halfWin-1)]);
endInd=min([length(curShockSig) eventInd(beginInd)+halfWin]);
curTemplate=curShockSig(startInd:endInd);
if(startInd>(eventInd(beginInd)-(halfWin-1)))
    %shorter in the beginning
    temp=zeros(winLen,1);
    temp(end-length(curTemplate)+1:end)=curTemplate;
    curTemplate=temp;
elseif(endInd<(eventInd(beginInd)+halfWin))
    temp=zeros(winLen,1);
    temp(1:length(curTemplate))=curTemplate;
    curTemplate=temp;
end
%curEvent=curShockSig(eventInd(i)-(halfWin-1):eventInd(i)+halfWin);
%align peak
%[peak maxInd]=max(abs(curEvent));
[peak, maxInd]=max(curTemplate);
diffInd=eventInd(beginInd)+(maxInd-(halfWin));
%check ranges
startInd=max([1 diffInd-(halfWin-1)]);
endInd=min([length(curShockSig) diffInd+halfWin]);
curTemplate=curShockSig(startInd:endInd);
if(startInd>(diffInd-(halfWin-1)))
    %shorter in the beginning
    temp=zeros(winLen,1);
    temp(end-length(curTemplate)+1:end)=curTemplate;
    curTemplate=temp;
elseif(endInd<(diffInd+halfWin))
    temp=zeros(winLen,1);
    temp(1:length(curTemplate))=curTemplate;
    curTemplate=temp;
end


%iterate through each vin event
%extract window around VIN
if(debug)
    %h1=figure;
    %h3=figure;
end
tempNSREpisode=curTemplate;
windowCount=1;
curMatchRatios=zeros(nb_averaged_beats,1);
i=1;
while(i<=size(eventInd,1))
    
    if (windowCount>cur_nb_averaged_beats )
        
        %if curMatchRatio>globalRatio, then update template
        if(debug==1)
            display(sprintf('curMatchRatios:%f \nglobalMatchRatio:%f',mean(curMatchRatios),globalMatchRatio))
        end
        if(mean(curMatchRatios)>globalMatchRatio)
            tempNSREpisode=mean(wave_win_array,2);
            if(debug)
            figure
            plot(tempNSREpisode)
            title('Current tempNSREpisode')
            
            display('UPDATE: Current match average was greater, updating')
            end
            globalMatchRatio=mean(curMatchRatios);
            
        end
        %begin looking at next window of beats, first beat is template
        beginInd=beginInd+1;
        
        %check ranges
        startInd=max([1 eventInd(beginInd)-(halfWin-1)]);
        endInd=min([length(curShockSig) eventInd(beginInd)+halfWin]);
        curTemplate=curShockSig(startInd:endInd);
        if(startInd>(eventInd(beginInd)-(halfWin-1)))
            %shorter in the beginning
            temp=zeros(winLen,1);
            temp(end-length(curTemplate)+1:end)=curTemplate;
            curTemplate=temp;
        elseif(endInd<(eventInd(beginInd)+halfWin))
            temp=zeros(winLen,1);
            temp(1:length(curTemplate))=curTemplate;
            curTemplate=temp;
        end
        %curEvent=curShockSig(eventInd(i)-(halfWin-1):eventInd(i)+halfWin);
        %align peak
        %[peak maxInd]=max(abs(curEvent));
        [peak maxInd]=max(curTemplate);
        
        diffInd=eventInd(beginInd)+(maxInd-(halfWin));
        %check ranges
        startInd=max([1 diffInd-(halfWin-1)]);
        endInd=min([length(curShockSig) diffInd+halfWin]);
        curTemplate=curShockSig(startInd:endInd);
        if(startInd>(diffInd-(halfWin-1)))
            %shorter in the beginning
            temp=zeros(winLen,1);
            temp(end-length(curTemplate)+1:end)=curTemplate;
            curTemplate=temp;
        elseif(endInd<(diffInd+halfWin))
            temp=zeros(winLen,1);
            temp(1:length(curTemplate))=curTemplate;
            curTemplate=temp;
        end
        wave_win_array=zeros(window_length,nb_averaged_beats);
        i=beginInd;
        windowCount=1;
        curMatchRatios=zeros(nb_averaged_beats,1);
    else
        %check ranges
        startInd=max([1 eventInd(i)-(halfWin-1)]);
        endInd=min([length(curShockSig) eventInd(i)+halfWin]);
        curEvent=curShockSig(startInd:endInd);
        if(startInd>(eventInd(i)-(halfWin-1)))
            %shorter in the beginning
            temp=zeros(length(curTemplate),1);
            temp(end-length(curEvent)+1:end)=curEvent;
            curEvent=temp;
        elseif(endInd<(eventInd(i)+halfWin))
            temp=zeros(length(curTemplate),1);
            temp(1:length(curEvent))=curEvent;
            curEvent=temp;
        end
        
        %curEvent=curShockSig(eventInd(i)-(halfWin-1):eventInd(i)+halfWin);
        %align peak
        %[peak maxInd]=max(abs(curEvent));
        [peak maxInd]=max(curEvent);
        
        diffInd=eventInd(i)+(maxInd-(halfWin));
        %check ranges
        startInd=max([1 diffInd-(halfWin-1)]);
        endInd=min([length(curShockSig) diffInd+halfWin]);
        curEvent=curShockSig(startInd:endInd);
        if(startInd>(diffInd-(halfWin-1)))
            %shorter in the beginning
            temp=zeros(length(curTemplate),1);
            temp(end-length(curEvent)+1:end)=curEvent;
            curEvent=temp;
        elseif(endInd<(diffInd+halfWin))
            temp=zeros(length(curTemplate),1);
            temp(1:length(curEvent))=curEvent;
            curEvent=temp;
        end
        
        
        %match to template
        matchP=med_wave_morph_comp(curEvent,curTemplate,DS,debug);
        curMatchRatios(windowCount)=matchP;
        wave_win_array(:,windowCount)=curEvent;
        if(debug)
            %display results
            figure
            hold off
            plot(curTemplate)
            hold on
            plot(curEvent)
            title(sprintf('Event %d, Match:%f%%',i,matchP*100))
            display(sprintf('beginInd:%d, eventInd:%d, wCount:%d',beginInd,i,windowCount));
            x=input('Press Enter to Continue');
            close all
        end
        
        windowCount=windowCount+1;
        i=i+1;
    end
end

if (debug==1)
    display('Template acquisition complete')
    %avgNSRTemp=mean(wave_win_array,2);
    figure;
    plot(tempNSREpisode);
    title('Acquired Template')
end
Med_state.NSR_temp=tempNSREpisode;

end