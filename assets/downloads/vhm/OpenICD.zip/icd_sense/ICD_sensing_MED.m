%ICD Sensing Function
%input: TBD
% % parameter struct
% (initial settings)
%ICD_sense_state
%State: 1 - sensing/AGC
%       2 - peak tracking
%       3 - absolute blanking
%       4 - noise window
%       5 - fixed refractory
% ICD_sense_state.State=1;
% ICD_sense_state.VPace=0;
% ICD_sense_state.VSense=0;
% ICD_sense_state.APace=0;
% ICD_sense_state.ASense=0;
% ICD_sense_state.StateClock=0;
% ICD_sense_state.StateClockLim=0;
% ICD_sense_state.RefPeriodClock=0;
% ICD_sense_state.VThres=vThresMin;
% ICD_sense_state.VType=1;
% ICD_sense_state.VAvg=vThresMin;%TODO: could be different initial value
% ICD_sense_state.DebugClock=0;

% current state
% current waveform sample (vector)
%output: TBD
% input waveform
% current threshold
%TODO: what happens when there is a VPACE event, but it is not sensed?
function [signal, V_in, A_in, V_blank, ICD_sense_state, ICD_sense_param]=ICD_sensing_MED(...
    ICD_sense_state, ICD_sense_param,...
    signal)


[Vsignal, V_out, A_null, V_blank,ICD_sense_state, ICD_sense_param]=ICD_sensing_MED_V(...
    ICD_sense_state, ICD_sense_param,...
    signal(:,1));

[Asignal, V_null, A_out, A_blank,ICD_sense_state, ICD_sense_param]=ICD_sensing_MED_A(...
    ICD_sense_state, ICD_sense_param,...
    signal(:,2));
V_in=V_out;
A_in=A_out;
signal=[Vsignal Asignal];

end