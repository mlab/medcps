function pat=PRpattern(SecondLastRR,LastRR,V_clk,lastV)
% Everything else
pat='Z';
% C,I,J
if isempty(find(SecondLastRR))
    % C,I
    if length(find(LastRR))==2
        % C
        if LastRR(1)>50 && LastRR(1)<V_clk/2 && LastRR(2)<V_clk-80 && LastRR(2)>=V_clk/2
            pat='C';
        end
        
        % I
        if LastRR(1)<=50 && LastRR(2)>=V_clk-80
            pat='I';
        end
    end
    
    % J
    if length(find(LastRR))==1 && LastRR(1)<50
        pat='J';
    end
end
% A,B,D,F,G,K,L,M,N,O
if length(find(SecondLastRR))==1
    % B,K
    if length(find(LastRR))==0
        % B
        if SecondLastRR(1)>lastV/2 && SecondLastRR(1)<lastV-80
            pat='B';
        end
        % K
        if SecondLastRR(1)>=lastV-80
            pat='K';
        end
    end
    % A,F,G,L,M,N
    if length(find(LastRR))==1
       % A,L
       if SecondLastRR(1)>lastV/2 && SecondLastRR(1)<lastV-80
           % A
           if LastRR(1)>V_clk/2 && LastRR(1)<V_clk-80
                pat='A';
           end
           % L
           if LastRR(1)>V_clk-80
               pat='L';
           end
       end
       % F
       if SecondLastRR(1)<50 && LastRR(1)<50
           pat='F';
       end
       % G,M
       if SecondLastRR(1)>lastV-80 
           % G
           if LastRR(1)>lastV-80
               pat='G';
           end
           % M
           if LastRR(1)>V_clk/2 && LastRR(1)<V_clk-80
               pat='M';
           end
       end
       % N
       if SecondLastRR(1)>=50 && SecondLastRR(1)<lastV/2 && LastRR(1)>=50 && LastRR(1)<V_clk/2
           pat='N';
       end
    end
    % D,O
    if length(find(LastRR))==2
        % D
        if SecondLastRR(1)>lastV/2 && SecondLastRR(1)< lastV-80 && LastRR(1)>=80 && LastRR(1)<V_clk/2 && LastRR(2)>=V_clk/2 && LastRR(2)<V_clk-80
            pat='D';
        else
            pat='O';
        end
    end
end

% E,H,P,Q
if length(find(SecondLastRR))==2
    % Q
    if length(find(LastRR))==2
        pat='Q';
    end
    % H
    if length(find(LastRR))==0 && SecondLastRR(1)<50 && SecondLastRR(2)>lastV-80
        pat='H';
    end
    % E,P
    if length(find(LastRR))==1
        %E
        if SecondLastRR(1)>50 && SecondLastRR(1)<lastV/2 && SecondLastRR(2)>lastV/2 && SecondLastRR(2)<lastV-80 && LastRR(1)>=V_clk/2 && LastRR(1)<V_clk-80
            pat='E';
        else
            pat='P';
        end
    end
    
end

if length(find(SecondLastRR))>0 && length(find(LastRR))>0 && length(find(SecondLastRR))+length(find(LastRR))>3
    pat='Y';
end

%return pat

end
    
