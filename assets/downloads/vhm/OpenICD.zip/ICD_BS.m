 function [ICD_state,therapy,inhibit,message]=ICD_BS(ICD_state,ICD_param, A_sense, V_sense,V_shock,message)
 % Initialization and resets
 ICD_state.VT=0;
 ICD_state.VF=0;
  ICD_state.VS=0;
   ICD_state.VBlk=0;
  ICD_state.ABlk=0;
   ICD_state.AR=0;
    ICD_state.AS=0;
    therapy=0;
    inhibit=0;
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % Time elapse
 % The only place where counters are increased
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 ICD_state.A_clk=ICD_state.A_clk+1;
 
 ICD_state.V_clk=ICD_state.V_clk+1;
 
 if length(ICD_state.VTC_morph)<201
    ICD_state.VTC_morph=[ICD_state.VTC_morph,V_shock];
 else
     ICD_state.VTC_morph(1)=[];
     ICD_state.VTC_morph=[ICD_state.VTC_morph,V_shock];
 end
 
 % VTC correlation algorithm
 if ICD_state.V_clk==100 && length(ICD_state.VTC_morph)>=201
     [V_morph,fcc]=VTC_cor(ICD_state.VTC_morph,ICD_state.NSR_temp);
     ICD_state.VTC_win=[ICD_state.VTC_win;V_morph];

 end



% During VFduration, count to 10
             if ICD_state.VFduration
                 ICD_state.VFdur_count=ICD_state.VFdur_count+1;
                 if length(find(ICD_state.V_win<ICD_param.VF_thresh))<6 || ICD_state.V_win(end)>ICD_param.VF_thresh
                     ICD_state.VFduration=0;
                     inhibit=1;
                     message=[message;{['t=',num2str(ICD_state.g_clk),',VF duration drop-off']}];
                 end
                 % Duration finishes
                 if ICD_state.VFdur_count>=ICD_param.VFdur_length
                     % Reset durations
                     ICD_state.VFduration=0;
                     ICD_state.VFdur_count=0;
                      % If less than 6/10 beats during duration or the last beat is slower
                     % than VF threshold, cancel episode.
                     if length(find(ICD_state.V_win<ICD_param.VF_thresh))<6 || ICD_state.V_win(end)>ICD_param.VF_thresh
                         % Do nothing, cancel episode
                         message=[message;{['t=',num2str(ICD_state.g_clk),',VF duration finish but inhibit']}];
                     else
                         %%%%%%%%%%%%%%%%%%%%%%%%%%%%
                         % ATP and shock
                         %%%%%%%%%%%%%%%%%%%%%%%%%%
                         % Todo
                         therapy=1;
                         message=[message;{['t=',num2str(ICD_state.g_clk),',VF therapy']}];
                     end
                 end
             end
% During VTduration, count to 10
             if ICD_state.VTduration
                 ICD_state.VTdur_count=ICD_state.VTdur_count+1;
                 if length(find(ICD_state.V_win<ICD_param.VT_thresh))<6 || ICD_state.V_win(end)>ICD_param.VT_thresh
                    ICD_state.VTduration=0;
                    inhibit=1;
                    message=[message;{['t=',num2str(ICD_state.g_clk),',VT duration drop-off']}];
                 end
                 % Duration finishes
                 if ICD_state.VTdur_count>=ICD_param.VTdur_length
                     ICD_state.VTduration=0;
                     ICD_state.VTdur_count=0;
                     % If less than 6/10 beats during duration or the last beat is slower
                     % than VT threshold, cancel episode.
                     if length(find(ICD_state.V_win<ICD_param.VT_thresh))<6 || ICD_state.V_win(end)>ICD_param.VT_thresh
                         % Do nothing, cancel episode
                         message=[message;{['t=',num2str(ICD_state.g_clk),',VT duration finish but inhibit']}];
                     else
                         %%%%%%%%%%%%%%%%%%%%%%%%%%%%
                         % discriminators decisions
                         %%%%%%%%%%%%%%%%%%%%%%%%%%
                         VgtA_decision=dis_VgtA(mean(ICD_state.A_win),mean(ICD_state.V_win));
                         VTC_decision=dis_VTC(ICD_state.VTC_win);
                         STB_decision=dis_STB(cov(ICD_state.V_win));
                         AFib_decision=dis_AFib(ICD_state.A_win,ICD_param.AFib_thresh);
                         if VgtA_decision
                             rhythm='VT';
                             therapy=1;
                             message=[message;{['t=',num2str(ICD_state.g_clk),',V>A therapy']}];
                         else
                             if VTC_decision
                                 rhythm='SVT';
                                 inhibit=1;
                                 message=[message;{['t=',num2str(ICD_state.g_clk),',V<A and VTC correlate inhibit']}];
                             else
                                 if AFib_decision && STB_decision
                                     rhythm='SVT';
                                     inhibit=1;
                                     message=[message;{['t=',num2str(ICD_state.g_clk),',V<A & VTC not correlate & AF STB inhibit']}];
                                 else
                                     rhythm='VT';
                                     therapy=1;
                                     message=[message;{['t=',num2str(ICD_state.g_clk),',V<A & VTC not correlate & AF STB therapy']}];
                                 end
                             end
                         end
                         
                         if strcmp(rhythm,'VT')
                             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                             % Todo
                             %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                             % 
                         end
                         
                         
                     end
                 end
             end
             
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % Detection
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 if A_sense
         % Slide sensing window
         ICD_state.A_win(1)=[];
         ICD_state.A_win=[ICD_state.A_win;ICD_state.A_clk];
         % Reset clock
         ICD_state.A_clk=0;
         % Atrial refractory within PVARP
         if ICD_state.V_clk>ICD_param.PVAB && ICD_state.V_clk<ICD_param.PVARP
             ICD_state.AR=1;
             
         else 
             % Atrial sense after PVARP
          %   if ICD_state.V_clk>ICD_param.PVARP
                 ICD_state.AS=1;
            % end
         end
 end
 

     

 if V_sense
          % Slide sensing window
         ICD_state.V_win(1)=[];
         ICD_state.V_win=[ICD_state.V_win;ICD_state.V_clk];
         
         % Slide Morphology window
         ICD_state.VTC_win(1)=[];
         
         %ICD_state.VTC_win=[ICD_state.VTC_win;V_sense];
         
         % Two-zone configuration with VT/VF
         if ICD_param.zone_num==2
             % VT
             if ICD_state.V_clk<ICD_param.VT_thresh && ICD_state.V_clk>=ICD_param.VF_thresh
                 ICD_state.VT=1;
                 
             end
             % VF
             if ICD_state.V_clk<ICD_param.VF_thresh
                 ICD_state.VF=1;
             end
             % VS
             if ICD_state.V_clk>=ICD_param.VT_thresh
                 ICD_state.VS=1;
             end
             % Initial detection for VT/VF
             % 8/10 V intervals and the last V interval less than VF
             % threshold. VF is prioritized
             if ICD_state.VFduration==0 && length(find(ICD_state.V_win<ICD_param.VF_thresh))>=8 && ICD_state.V_win(end)<ICD_param.VF_thresh
                % VFduration starts
                 ICD_state.VFduration=1;
                 ICD_state.VFdur_count=0;
                 message=[message;{['t=',num2str(ICD_state.g_clk),',VF duration start']}];
                 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
                 % To do
                 %%%%%%%%%%%%%%%%%%%%%%%%%%%%
                 % Episode start and marker recording
                 
                     
             else
                 % 8/10 V intervals and the last V interval less than VT
                 % threshold
                 if ICD_state.VTduration==0 && length(find(ICD_state.V_win<ICD_param.VT_thresh))>=8 && ICD_state.V_win(end)<ICD_param.VT_thresh
                     % VTduration starts
                     ICD_state.VTduration=1;
                     ICD_state.VTdur_count=0;
                     message=[message;{['t=',num2str(ICD_state.g_clk),',VT duration start']}];
                 end
             end
             
             
         else
             if ICD_param.zone_num==1
                 %%%%%%%%%%%%%%%%%%%%%%%%
                 % todo
                 %%%%%%%%%%%%%%%%%%%%%%%%
             end
             if ICD_param.zone_num==3
                 %%%%%%%%%%%%%%%%%%%%%%%%
                 % todo
                 %%%%%%%%%%%%%%%%%%%%%%%%
             end
             
         end
         
         % Reset clock
         ICD_state.V_clk=0;
 end
 
 
 
 
 
 
 
 
 
 
 
 
 