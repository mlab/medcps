function [V_morph,fcc]=VTC_cor(VTC_morph,NSR_temp)
x=NSR_temp.refy;
y=VTC_morph(NSR_temp.refx);

VTC_corr_th=0.94;
fcc=(8*sum(x.*y)-(sum(x)*sum(y)))^2/((8*sum(x.^2)-sum(x)^2)*(8*sum(y.^2)-sum(y)^2));
if fcc>= VTC_corr_th
    V_morph=1;
else
    V_morph=2;
end
% subplot(2,1,1)
% gcf;
% plot(NSR_temp.raw)
% hold on;
% %subplot(2,1,2)
% plot(VTC_morph,'color','red')
% hold off;
% 1;