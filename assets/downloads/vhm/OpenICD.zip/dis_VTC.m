function VTC_decision=dis_VTC(VTC_win)

num_correlate=length(find(VTC_win==1));

if num_correlate>=3
    VTC_decision=true;
else
    VTC_decision=false;
end

