clear all
addpath('icd_sense')
load EGM-1-1-4.mat
% sensing
bevents=icd_sense(EGM,'bsc');
% detection
[ICD_state, ICD_param ] = initialize_icd('bsc');
nb_averaged_beats = 15;
% acquire NSR template
ICD_state = acquire_VTC_template(bevents,ICD_state,EGM,nb_averaged_beats);

NSR_length=10000;
Vlog=[];
Alog=[];
im = 0;
message=[];
N = length(bevents.Ain);
for t=1:N
    A_in=bevents.Ain(t);
    V_in=bevents.Vin(t);
    V_shock=EGM.Shock(t);
    ICD_state.g_clk=t+NSR_length;
    [ICD_state,BStherapy,BSinhibit,message]=ICD_BS(ICD_state,ICD_param, A_in, V_in,V_shock,message);        
    Vlog=[Vlog;V_in];
    Alog=[Alog;A_in];    
    im = im+1;
    marker_time(im,:) = ...
        [
        ICD_state.AS, ICD_state.AR, ICD_state.ABlk, ICD_state.VS, ...
        ICD_state.VT, ICD_state.VF, ICD_state.VBlk, ICD_state.VTduration, ...
        ICD_state.VFduration, BStherapy, BSinhibit
        ];
   
    bsc_therapy = BStherapy*~BSinhibit;

end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Medtronic
mevents=icd_sense(EGM,'med');%,[], nominal_MED_thresholds);
N = length(mevents.Ain);
% detection
[Med_state, Med_param] = initialize_icd('med');
Vlog=[];
Alog=[];
marker_time1 = nan(N - NSR_length+1, 6);
pattern=[];

template_window_length=128;
DownSamplingFactor=4;
nb_averaged_beats=6;
debug=0;
% nb_averaged_beats = 15;
% ICD_state = acquire_VTC_template(ICD_state,egm,nb_averaged_beats);
Med_state= acquire_med_wavelet_template(NSR_length,mevents,Med_state,EGM, template_window_length,DownSamplingFactor, nb_averaged_beats, debug);

im = 0;
for t=1:N
    A_in=mevents.Ain(t);
    V_in=mevents.Vin(t);
    V_shock=EGM.Shock(t);
        
    [Med_state,status,Medtherapy,Medinhibit]=ICD_Med_det(Med_state,Med_param, A_in, V_in, V_shock);
    Vlog=[Vlog;V_in];
    Alog=[Alog;A_in];
    
    im=im+1;
    marker_time1(im,:) = [
        Med_state.AS, Med_state.VS, ...
        Med_state.VT, Med_state.VF, ...
        Medtherapy, Medinhibit
        ];
    if Med_state.VS || Med_state.VF || Med_state.VT
        pattern=[pattern,Med_state.PRpattern(end)];        
    end
    med_therapy = Medtherapy*~Medinhibit;
    
end
marker_time1 = marker_time1(1:im,:);
med_markers.markers= marker_time1;
med_markers.pattern=pattern;
    

plotTrace(EGM,marker_time,marker_time1,pattern);
