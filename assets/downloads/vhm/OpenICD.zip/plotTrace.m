function plotTrace(EGM,marker_time,marker_time1,pattern)
mark={sprintf('A\nS'),sprintf('A\nR'),sprintf('A\nB'),sprintf('V\nS'),sprintf('V\nT'),sprintf('V\nF'),'VBlk','VT\_dur','VF\_dur','S','I'};
mark1={sprintf('A\nS'),sprintf('V\nS'),sprintf('V\nT'),sprintf('V\nF'),'S','I'};

mark_alt=[2.5,2.5,2.1,-2.5,-2.5,-2.5,-1.9,-3.5,-3.5,-4,-4];
mark_alt1=[2.5,-2.5,-2.5,-2.5,-4,-4];

mark_c={'black','black','red','black','black','black','black','black','black','red','green'};
mark_c1={'black','black','black','black','red','green'};

figure
axes

plot(EGM.ASigRaw(1:end)./(max(EGM.ASigRaw)-min(EGM.ASigRaw)).*4+20);

hold on
plot(EGM.VSigRaw(1:end)./(max(EGM.VSigRaw)-min(EGM.VSigRaw)).*4+16);
hold on
plot(EGM.Shock(1:end)./(max(EGM.Shock)-min(EGM.Shock)).*4+12);


marker_time(:,end-3)=[0;diff(marker_time(:,end-1))];
marker_time(:,end-2)=[0;diff(marker_time(:,end))];

hold on
plot(6+3.*sum(marker_time(:,1:3),2));
hold on
plot(6-3.*sum(marker_time(:,4:end-4),2));
hold on
temp=find(sum(marker_time(:,1:2),2));
temp1=diff(temp);
if length(temp)>=2
ind=temp(1:end-1)+floor(temp1./2);
else
    ind=[];
end
for i=1:length(ind)
    text(ind(i)-1,7,sprintf('%d\n%d\n%d',floor(temp1(i)/100),mod(temp1(i)-floor(temp1(i)/100)*100,10),mod(temp1(i),10)),'fontsize',7,'color','red');
end
hold on
temp=find(sum(marker_time(:,4:6),2));
temp1=diff(temp);
if length(temp)>=2
ind=temp(1:end-1)+floor(temp1./2);
else
    ind=[];
end
for i=1:length(ind)
    text(ind(i)-1,5,sprintf('%d\n%d\n%d',floor(temp1(i)/100),mod(temp1(i)-floor(temp1(i)/100)*100,10),mod(temp1(i),10)),'fontsize',7,'color','red');
end
for i=1:size(marker_time,2)
    ind=find(marker_time(:,i));
    text(ind-1,6+mark_alt(i).*ones(1,length(ind)),mark{i},'fontsize',9,'color',mark_c{i});
    
end

hold on
plot(-2+3.*sum(marker_time1(:,1),2));
hold on
plot(-2-3.*sum(marker_time1(:,2:end-2),2));
hold on
hold on
temp=find(marker_time1(:,1));
temp1=diff(temp);
ind=temp(1:end-1)+floor(temp1./2);
for i=1:length(ind)
    text(ind(i)-1,-1,sprintf('%d\n%d\n%d',floor(temp1(i)/100),mod(temp1(i)-floor(temp1(i)/100)*100,10),mod(temp1(i),10)),'fontsize',7,'color','red');
end
hold on
temp=find(sum(marker_time1(:,2:4),2));
temp1=diff(temp);
if length(temp)>=2
ind=temp(1:end-1)+floor(temp1./2);
else
    ind=[];
end
for i=1:length(ind)
    text(ind(i)-1,-3,sprintf('%d\n%d\n%d',floor(temp1(i)/100),mod(temp1(i)-floor(temp1(i)/100)*100,10),mod(temp1(i),10)),'fontsize',7,'color','red');
end
ind=find(sum(marker_time1(:,2:end),2));

for i=1:length(ind)
text(ind(i),-5.5,pattern(i),'color','blue');
end

for i=1:size(marker_time1,2)
    ind=find(marker_time1(:,i));
    if ~isempty(ind)
    text(ind,-2+mark_alt1(i).*ones(1,length(ind)),mark1{i},'fontsize',9,'color',mark_c1{i});
    end
end
set(gca,'Ylim',[-7,23]);
