 function [Med_state,status,therapy,inhibit]=ICD_Med_det(Med_state,Med_param, A_sense, V_sense, V_shock)
status='NSR';
therapy=0;
inhibit=0;
 % Initialization and resets
 Med_state.VT=0;
 Med_state.VF=0;
  Med_state.VS=0;

    Med_state.AS=0;

    his_bin=230:10:400;
    bin_count=zeros(length(his_bin)-1,1);
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % Time elapse
 % The only place where counters are increased
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 Med_state.A_clk=Med_state.A_clk+1;
 
 Med_state.V_clk=Med_state.V_clk+1;
 if(length(Med_state.shock_buf)<Med_param.shock_buf_len)
     Med_state.shock_buf=[Med_state.shock_buf; V_shock];
 else
     Med_state.shock_buf(1)=[];
     Med_state.shock_buf=[Med_state.shock_buf;V_shock];
 end
 
 if ((Med_state.V_clk==Med_param.wave_win_len) && length(Med_state.shock_buf)>=Med_param.shock_buf_len)
     %find max around center of current buffer state
     midShockInd=floor(Med_param.shock_buf_len/2);
     halfWinInd=floor(Med_param.wave_win_len/2); %NOTE: for now assume will always be even
     tempWin=Med_state.shock_buf((midShockInd-(halfWinInd)+1):midShockInd+halfWinInd);
     [peak maxInd]=max(abs(tempWin));
     diffInd=midShockInd+(maxInd-halfWinInd);
     tempWin=Med_state.shock_buf(diffInd-(halfWinInd-1):diffInd+halfWinInd);
     %save window into Med_state_wave_win
     Med_state.wave_win_array(:,Med_state.wave_win_count)=tempWin;
     if(Med_state.wave_win_count>8)
         Med_state.wave_win_count=1;
     end
 end

 
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 % Detection
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
 if A_sense
         % Slide sensing window
         Med_state.A_win(1)=[];
         Med_state.A_win=[Med_state.A_win,Med_state.A_clk];
         % Reset clock
         Med_state.A_clk=0;
        
         Med_state.AS=1;
         Med_state.LastRR=[Med_state.LastRR,Med_state.V_clk];
         
 end
 

     

 if V_sense
     %reset shock_buffer and save appropriate window
     
     if Med_state.V_clk<=Med_param.VF_thresh
         Med_state.VF=1;
         %Med_state.ConVT=0;
     else
         if Med_state.V_clk<=Med_param.VT_thresh
            Med_state.VT=1;
            Med_state.ConVT=Med_state.ConVT+1;
         else
             Med_state.VS=1;
             Med_state.ConVT=0;
         end
     end
     
          % Slide sensing window
         Med_state.V_win(1)=[];
         Med_state.V_win=[Med_state.V_win,Med_state.V_clk];
         % calculate onset
         
         % Slide Morphology window
         Med_state.VTC_win(1)=[];
         Med_state.VTC_win=[Med_state.VTC_win,V_sense];
         % Slide PR window
         Med_state.PRwin(1)=[];
         if ~isempty(Med_state.LastRR)
             Med_state.PRwin=[Med_state.PRwin,Med_state.V_clk-Med_state.LastRR(end)];
         else
             Med_state.PRwin=[Med_state.PRwin,Inf];
         end
         % PR association
         Med_state.PRassociate(1)=[];
         if Med_state.PRwin(end)==Inf
             Med_state.PRassociate=[Med_state.PRassociate,0];
         else if abs(Med_state.PRwin(end)-mean(Med_state.PRwin(Med_state.PRassociate<Inf)))>40
                 Med_state.PRassociate=[Med_state.PRassociate,0];
             else
                 Med_state.PRassociate=[Med_state.PRassociate,1];
             end
         end
         % RR regularity
         for i=1:length(his_bin)-1
             bin_count(i)=length(find(Med_state.V_win(7:end)>=his_bin(i) & Med_state.V_win(7:end)<his_bin(i+1)));
         end
         temp=sort(bin_count);
         Med_state.RRreg=sum(temp(end-1:end));
         % Slide NOA window
         Med_state.NOA_win(1)=[];
         Med_state.NOA_win=[Med_state.NOA_win,length(Med_state.LastRR)];
          % Save the pattern
         Med_state.PRpattern(1)=[];
         Med_state.PRpattern=[Med_state.PRpattern,PRpattern(Med_state.SecondLastRR,Med_state.LastRR,Med_state.V_clk,Med_state.V_win(end-1))];
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         % Counters for different patterns
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        % Sinus Tachycardia
        %%%%%%%%%%%%%%%%%%%%%
        % Last letter is A
        if Med_state.PRpattern(end)=='A'
            % upper bound is 13
            if Med_state.STcount<13 
                Med_state.STcount=Med_state.STcount+1;
            end
            % intermediate state just hold
        else if ~isempty(find(regexp(Med_state.PRpattern,'AB|AD|AL')==4))...
                    || ~isempty(find(regexp(Med_state.PRpattern,'ABC|ADE|ALM|ABZ')==3))...
                    || ~isempty(find(regexp(Med_state.PRpattern,'ABCE')==2))
            else
                Med_state.STcount=Med_state.STcount-4;
                if Med_state.STcount<0
                    Med_state.STcount=0;
                end
            end
        end
        %%%%%%%%%%%%%%
        % Other SVT
        %%%%%%%%%%%%%%
        % last letter is F/G
        if ~isempty(find(regexp(Med_state.PRpattern,'[FG]')==5))
            Med_state.OtherSVT=Med_state.OtherSVT+1;
        else if ~isempty(find(regexp(Med_state.PRpattern,'[FG]O')==4))...
                    || ~isempty(find(regexp(Med_state.PRpattern,'[FG]OH')==3))...
                    || ~isempty(find(regexp(Med_state.PRpattern,'[FG]OH[JI]')==2))...
                    || ~isempty(find(regexp(Med_state.PRpattern,'OHIHJ')==1))
            else
                Med_state.OtherSVT=0;
            end
        end
        %%%%%%%%%%
        % AF AFL
        %%%%%%%%%%
        if ~isempty(find(regexp(Med_state.PRpattern,'[QYDEP]')==5))...
                || ~isempty(find(regexp(Med_state.PRpattern,'PO')==4))
            Med_state.AFcount=Med_state.AFcount+1;
        else
            Med_state.AFcount=0;
        end
        %%%%%%%%%%%
        % FFRW
        %%%%%%%%%%%
        Med_state.FFRW_win(1)=[];
        if length(Med_state.LastRR)==2 && (Med_state.LastRR(1)<160 || Med_state.LastRR(2)>60)
            Med_state.FFRW_win=[Med_state.FFRW_win,1];
        else
            Med_state.FFRW_win=[Med_state.FFRW_win,0];
        end
        % FFRW pattern
        if length(Med_state.LastRR)==1
            if Med_state.LastRR(1)>=Med_state.V_clk/2 && Med_state.LastRR(1)<Med_state.V_clk-80
                Med_state.FFRW=Med_state.FFRW+1;
            else
                if Med_state.FFRW<6
                    Med_state.FFRW=0;
                else
                    Med_state.FFRW=Med_state.FFRW-2;
                end
            end
        else if length(Med_state.LastRR)==2
                if Med_state.LastRR(2)>=Med_state.V_clk/2 && Med_state.LastRR(2)<Med_state.V_clk-80
                Med_state.FFRW=Med_state.FFRW+1;
            else
                if Med_state.FFRW<6
                    Med_state.FFRW=0;
                else
                    Med_state.FFRW=Med_state.FFRW-2;
                end
                end
            end
        end
        %%%%%%%%%%%%%%
        % AF evidence
        %%%%%%%%%%%%%%
        if length(Med_state.LastRR)>2
            Med_state.AFevidence=Med_state.AFevidence+1;
        else if length(Med_state.LastRR)==2
                if Med_state.LastRR(2)>=Med_state.V_clk/2 && Med_state.LastRR(2)<Med_state.V_clk-80
                else
                    Med_state.AFevidence=Med_state.AFevidence+1;
                end
            else
                if Med_state.AFevidence>0
                    Med_state.AFevidence=Med_state.AFevidence-1;
                end
            end
        end
         %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
         % Start PRLogic
        
         
         if median(Med_state.V_win(13:end))<Med_param.VT_thresh || length(find(Med_state.V_win(end-8:end)<Med_param.VF_thresh))+length(find(Med_state.V_win(end-8:end)<Med_param.VT_thresh))>=8
          % Median RR less than SVT limit
          if median(Med_state.V_win(13:end))<Med_param.SVTlim
             if length(find(Med_state.V_win<Med_param.VF_thresh))>=Med_param.VF_length && length(find(Med_state.V_win(end-8:end)<Med_param.VF_thresh))>=18%change 18 --> 8 in first 
                 status='VF0';
                 therapy=2;
             end
             if Med_state.ConVT>=Med_param.VF_length && length(find(Med_state.V_win(end-8:end)<Med_param.VT_thresh))>=18%change 18 --> 8 in first
                 status='VT0';
                 therapy=1;
             end
             if Med_state.ConVT+length(find(Med_state.V_win<Med_param.VF_thresh))>21 && length(find(Med_state.V_win<Med_param.VF_thresh))>=6
                 status='VF1';
                 therapy=2;
             end
             
          else
             % Double Tachy (VF zone)
             if (length(find(Med_state.V_win<Med_param.VF_thresh))>=Med_param.VF_length && length(find(Med_state.V_win(end-8:end)<Med_param.VF_thresh))>=8) ...
                     || (Med_state.ConVT+length(find(Med_state.V_win<Med_param.VF_thresh))>21 && length(find(Med_state.V_win<Med_param.VF_thresh))>=6) ...
                     && Med_state.AFevidence>=6 ...
                     && sum(Med_state.PRassociate)<4
                     status='VF+SVT';
                     therapy=2;
             else
                 % Double Tachy (VT zone)
                 if Med_state.ConVT>=Med_param.VF_length && length(find(Med_state.V_win(end-8:end)<Med_param.VT_thresh))>=8 ...
                     && Med_state.AFevidence>=6 ...
                     && sum(Med_state.PRassociate)<4 ...
                     && Med_state.RRreg>14
                     status='VT+SVT';
                     therapy=1;
                 else
                     % AF/AFL
                     if Med_state.FFRW<10 && (Med_state.AFcount>=6 ...
                             || (Med_state.AFevidence>=6 ...
                                 && median(Med_state.A_win)<0.94*median(Med_state.V_win(end-12:end)) ...
                                 && Med_state.RRreg<=9)...
                                 && med_wavelet_check_morph(Med_state.wave_win_array,...
                                                            Med_state.NSR_temp,...
                                                            Med_param.wave_match_thres,...
                                                            Med_param.morph_thres,...
                                                            0))
                         status='AFAFL';
                         inhibit=1;
                     else
                         % Sinus Tachy
                         if Med_state.STcount>=6 || (Med_state.FFRW>=6 && length(find(Med_state.FFRW_win))>=10 ...
                                 && med_wavelet_check_morph(Med_state.wave_win_array,...
                                                            Med_state.NSR_temp,...
                                                            Med_param.wave_match_thres,...
                                                            Med_param.morph_thres,...
                                                            0))
                            status='ST';
                            inhibit=1;
                         else
                            % Other SVT
                            if (Med_state.OtherSVT>=6 ...
                                && med_wavelet_check_morph(Med_state.wave_win_array,...
                                                            Med_state.NSR_temp,...
                                                            Med_param.wave_match_thres,...
                                                            Med_param.morph_thres,...
                                                            0))
                                status='OtherSVT';
                                inhibit=1;
                            else
                                % VT/VF
                                if length(find(Med_state.V_win<Med_param.VF_thresh))>=Med_param.VF_length && length(find(Med_state.V_win(end-8:end)<Med_param.VF_thresh))>=8
                                     status='VF2';
                                     therapy=2;
                                 end
                                 if Med_state.ConVT>=Med_param.VF_length && length(find(Med_state.V_win(end-8:end)<Med_param.VT_thresh))>=8
                                     status='VT2';
                                     therapy=1;
                                 end
                                 if Med_state.ConVT+length(find(Med_state.V_win<Med_param.VF_thresh))>21 && length(find(Med_state.V_win<Med_param.VF_thresh))>=6
                                     status='VF3';
                                     therapy=2;
                                 end
                            end
                         end
                
                     end
                 end
             end
          end
         end


         % Reset clock
         Med_state.V_clk=0;
         
         Med_state.SecondLastRR=Med_state.LastRR;
         Med_state.LastRR=[]; 
 end
 
 
 
 
 
 
 
 
 
 
 
 
 