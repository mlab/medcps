clear all
addpath('icd_sense')
load EGM-1-1-6.mat
% sensing
bevents=icd_sense(EGM,'bsc');
% detection
[ICD_state, ICD_param ] = initialize_icd('bsc');
nb_averaged_beats = 15;
% acquire NSR template
ICD_state = acquire_VTC_template(bevents,ICD_state,EGM,nb_averaged_beats);

NSR_length=10000;
Vlog=[];
Alog=[];
im = 0;
message=[];
N = length(bevents.Ain);
for t=1:N
    A_in=bevents.Ain(t);
    V_in=bevents.Vin(t);
    V_shock=EGM.Shock(t);
    ICD_state.g_clk=t+NSR_length;
    [ICD_state,BStherapy,BSinhibit,message]=ICD_BS(ICD_state,ICD_param, A_in, V_in,V_shock,message);        
    Vlog=[Vlog;V_in];
    Alog=[Alog;A_in];    
    im = im+1;
    marker_time(im,:) = ...
        [
        ICD_state.AS, ICD_state.AR, ICD_state.ABlk, ICD_state.VS, ...
        ICD_state.VT, ICD_state.VF, ICD_state.VBlk, ICD_state.VTduration, ...
        ICD_state.VFduration, BStherapy, BSinhibit
        ];
   
    bsc_therapy = BStherapy*~BSinhibit;

end
plotTrace(EGM,marker_time)