function [nbAbeats, nbVbeats] = count_true_beats(egm)
% An event lasts a whole millisecond so detect rising edge
d = egm.RAin(1:end-1) - egm.RAin(2:end);
event_time = find(d==-1);
nbAbeats = length(event_time);
d = egm.RVin(1:end-1) - egm.RVin(2:end);
event_time = find(d==-1);
nbVbeats = length(event_time);