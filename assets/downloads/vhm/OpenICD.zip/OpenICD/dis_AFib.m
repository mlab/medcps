function AFib_decision=dis_AFib(A_win,AF_thresh)

if length(find(A_win<AF_thresh))>=6
    AFib_decision=true;
else
    AFib_decision=false;
end
