function VgtA_decision=dis_VgtA(meanA,meanV)
VgtA_decision=false;
if 60000/meanV-60000/meanA>10
    VgtA_decision=true;
end