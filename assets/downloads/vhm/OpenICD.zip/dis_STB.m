function STB_decision=dis_STB(covV)
if covV>20
    STB_decision=false;
else
    STB_decision=true;
end
