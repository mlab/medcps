function mat_GUI
% Initialize
clear all
close all
bdclose('all');
% GUI figure
hf=figure('units','pixels',...
          'Position',[100 100 600 300],...
          'Name','VHM Simulink V1.0',...
          'NumberTitle','off');
a=axes('ytick',[],...
       'xlim',[0 5000],...
       'ylim',[-2 2],...
       'units','pixels',...
       'nextplot','add',...
       'Position',[50 100 500 120]);
% Control buttons
uicontrol('style','pushbutton',...
         'string','Start',...
         'callback',@startpushed,...
         'position',[50 50 100 20]);
uicontrol('style','pushbutton',...
         'string','Stop',...
         'callback',@stoppushed,...
         'position',[170 50 100 20]);
uicontrol('style','popup',...
         'String','NSR|Brady|Block',...
         'callback',@Case_select,...
         'position',[300 50 100 20]);    
uicontrol('style','togglebutton',...
         'string','PAC',...
         'callback',@PACpushed,...
         'position',[450 50 50 20]);
uicontrol('style','togglebutton',...
         'string','PVC',...
         'callback',@PVCpushed,...
         'position',[500 50 50 20]);

% load model
modelName='test';
Config.modelSim=sprintf('%s_scope',modelName);
load(modelName);
simulink;
open_system('SimpleModeling');
open_system(Config.modelSim);
figure(hf);

% set simulation parameters
set_param(Config.modelSim,'StopTime','Inf');
set_param(Config.modelSim,'SimulationMode','normal');

% GUI data
Config.node_name=node_name;
Config.path_name=path_names;
Config.a=a;
% display cache
Config.temp=zeros(5,5000);

guidata(hf,Config);
end



function startpushed(hObject,eventdata)
Config = guidata(gcf);

set_param(Config.modelSim,'SimulationCommand','start');

% add listener to pacemaker outputs
localAddListener;

end
function stoppushed(hObject,eventdata)

Config = guidata(gcf);
set_param(Config.modelSim,'SimulationCommand','stop');

end

function PACpushed(hObject,eventdata)
Config = guidata(gcf);
block_name=sprintf('%s/PAC_en',Config.modelSim);

set_param(block_name,'Value',num2str(get(hObject,'value')));

end
function PVCpushed(hObject,eventdata)
Config = guidata(gcf);
block_name=sprintf('%s/PVC_en',Config.modelSim);

set_param(block_name,'Value',num2str(get(hObject,'value')));

end

function Case_select(hObject,eventdata)
Config = guidata(gcf);
val=get(hObject,'Value');
block_name=sprintf('%s/c_num',Config.modelSim);

set_param(block_name,'Value',num2str(val));
end
function localAddListener
Config=guidata(gcf);

block_name=sprintf('%s/PM/pacem_aut',Config.modelSim);
Config.PM=add_exec_event_listener(block_name,'PostOutputs',@PMListener);
guidata(gcf,Config);
end

function PMListener(block, eventdata)
Config=guidata(gcf);
h=[1.5,-1.5,0.5,-0.5,1]; 
str={'AP','VP','AS','VS','AR'};
cla
 for i=1:5

    Config.temp(i,:)=[Config.temp(i,2:end), block.OutputPort(i).data];
    temp=find(Config.temp(i,:));
  
   if ~isempty(temp)
    text(temp,h(i).*ones(length(temp),1),str{i});
   else
       text(100,100,'');
   end
        
 end

guidata(gcf,Config);
end
